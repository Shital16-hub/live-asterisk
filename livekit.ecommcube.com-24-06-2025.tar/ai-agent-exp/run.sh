
# export LIVEKIT_API_KEY=devkey
# export LIVEKIT_API_SECRET=secret
# export LIVEKIT_URL=ws://localhost:7880

export LIVEKIT_URL=wss://livekit.agproclub.com
export LIVEKIT_API_KEY=APInaFJkumkKzns
export LIVEKIT_API_SECRET=Wh75L1MHxwkCN38HPleykcNjxNn3bS1h3Zh1T1HTWuM
ASSEMBLYAI_API_KEY=2540fb662f144e54a8cb0b541c8bf5ae
clear && python voice_bot.py console



# Local terminal mode (mic & speaker I/O):
# [oai_citation_attribution:6‡GitHub](https://github.com/livekit/agents/blob/main/README.md)
# Local terminal mode (mic & speaker I/O):
# livekit-server --dev --config livekit.yaml








# # Development mode (hot reload):


# export LIVEKIT_API_KEY=devkey
# export LIVEKIT_API_SECRET=secret
# export LIVEKIT_URL=ws://localhost:7880
# python voice_bot.py dev

# # Production mode:
# python voice_bot.py start
# python voice_bot.py console  

# # Development mode (hot reload):
# python voice_bot.py dev  [oai_citation_attribution:7‡LiveKit Docs](https://docs.livekit.io/python/livekit/agents/cli/cli.html?utm_source=chatgpt.com)

# # Production mode:
# python voice_bot.py start  [oai_citation_attribution:8‡LiveKit Docs](https://docs.livekit.io/python/livekit/agents/cli/cli.html?utm_source=chatgpt.com)