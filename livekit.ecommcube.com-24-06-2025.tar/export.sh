export API_KEY=APILodLwqNKJYqE
export API_SECRET=TIbzUfLfcCd6KZjZlGgbxnKqTsHBy7zDe5bzDe9gg3UB
export WS_URL=ws://localhost:7880
export REDIS_ADDRESS=localhost:6379
export SIP_PORT=5060
export RTP_PORT=10000-20000
export USE_EXTERNAL_IP=true
export FLOOD_PROTECTION=false